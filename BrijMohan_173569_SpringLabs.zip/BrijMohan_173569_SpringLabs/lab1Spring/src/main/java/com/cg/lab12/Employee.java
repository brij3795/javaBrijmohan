package com.cg.lab12;

public class Employee {
	
	private int employeeId;
	private int employeeAge;
	private String employeeName;
	private Sbu businessUnit;
	private double salary;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getEmployeeAge() {
		return employeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Sbu getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(Sbu businessUnit) {
		this.businessUnit = businessUnit;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeAge=" + employeeAge + ", employeeName=" + employeeName
				+ ", businessUnit=" + businessUnit + ", salary=" + salary + "]";
	}
	
	
	
	
	
	
	
	
	

}

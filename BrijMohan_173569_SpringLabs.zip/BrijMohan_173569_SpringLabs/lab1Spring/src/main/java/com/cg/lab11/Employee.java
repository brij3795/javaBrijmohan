package com.cg.lab11;

public class Employee {

	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	private String employeeBu;
	private int employeeAge;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeBu() {
		return employeeBu;
	}

	public void setEmployeeBu(String employeeBu) {
		this.employeeBu = employeeBu;
	}

	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + ", employeeBu=" + employeeBu + ", employeeAge=" + employeeAge + "]";
	}

	
	
	

}

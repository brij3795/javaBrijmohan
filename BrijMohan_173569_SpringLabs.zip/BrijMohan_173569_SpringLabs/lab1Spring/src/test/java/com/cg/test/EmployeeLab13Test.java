package com.cg.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab11.Employee;
import com.cg.lab13.Sbu;

public class EmployeeLab13Test {
	
	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("employeelab13.xml");
		
		Sbu sbu=  (Sbu) ctx.getBean("emp");
		System.out.println(sbu);
	}

}

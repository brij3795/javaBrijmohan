package com.cg.ctlr;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeInterface;

@Scope("session")
@Controller
public class UserController {
	ArrayList<String> domList;
	ArrayList<String> locList;

	@Autowired
	private TraineeInterface service;

	@RequestMapping("/checkLogin")
	public String checkLogin(Login login, Model mod) {
		String invalid = "Enter Valid details";
		mod.addAttribute("invalid", invalid);
		return "addTrainee";
	}

	@RequestMapping("/")
	public String homePage(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping("/delete")
	public String deleteTrainee(Model mod) {
		mod.addAttribute("trainee", new Trainee());
		return "deleteTrainee ";

	}

	@RequestMapping("/modify")
	public String modifyTrainee(Model mod) {
		mod.addAttribute("trainee", new Trainee());
		return "modifyTrainee ";

	}

	@RequestMapping("/retrieveAll")
	public String retrieveAllTrainee(Model m) {
		List<Trainee> list = null;
		m.addAttribute("list", list);
		return "retrieveAllTrainee";
	}

	@RequestMapping("/retrieve")
	public String retrieveTrainee(Model mod) {
		mod.addAttribute("trainee", new Trainee());
		return "retrieve Trainee";
	}

	@RequestMapping(path = "add")
	public String save(@ModelAttribute("trainee") Trainee trainee, Model mod) {

		service.addTrainee(trainee);
		mod.addAttribute("login", new Login());
		return "trainee";
	}

	@RequestMapping("/add")
	public String addtrainee(Model mod) {
		locList = new ArrayList<String>();

		locList.add("Noida");
		locList.add("Mumbai");
		locList.add("kolkatta");
		locList.add("Bangalore");

		domList = new ArrayList<String>();

		domList.add("Java");
		domList.add("JavaScipts");
		domList.add("Angular");
		domList.add("Spring");

		mod.addAttribute("trainee", new Trainee());
		mod.addAttribute("domainList", domList);
		mod.addAttribute("locationList", locList);

		return "trainee";

	}

}
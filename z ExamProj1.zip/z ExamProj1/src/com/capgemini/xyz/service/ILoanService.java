package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanService {

	String userNamePattern="[A-Z][a-z]{2}";
//	String emailPattern= "/\\S+@\\S+\\.\\S+/";
	String emailPattern= "^(.+)@(.+)$";
	String mobNoPattern="(0/91)?[7-9][0-9]{9}";
	float FixInterestRate= 9.5f;
	boolean validateUsername(String userName);
	boolean validateEmail(String email);
	boolean validateMobNo(String mobno);
	public void applyLoan (Loan loan);
	void insertCust(Customer customer);
	public double calculateEMI(double amount, int duration);
}

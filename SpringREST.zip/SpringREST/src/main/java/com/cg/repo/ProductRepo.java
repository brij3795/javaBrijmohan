package com.cg.repo;

import cg.com.entity.Product;
import antlr.collections.List;

public interface ProductRepo {

	void saveProduct(Product p);

	ProductRepo get(int id);

	java.util.List<Product> getAll();

}

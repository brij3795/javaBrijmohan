package com.cg.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import antlr.collections.List;
import cg.com.entity.Product;

public abstract  class ProductRepoImpl implements ProductRepo {

	@PersistenceContext(unitName = "Spring-JPA")
	private EntityManager em;

	@Transactional(propagation = Propagation.SUPPORTS)
	public Product getProduct(int id) {
		return em.find(Product.class, id);

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveProduct(Product p) {
		em.persist(p);

	}

	public java.util.List<Product> getAllProduct() {
		return em.createQuery("from Product").getResultList();
	}

}

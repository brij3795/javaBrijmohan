import { Injectable, OnInit } from '@angular/core';
import { ToDoTasks } from '../Models/ToDoTasks';

@Injectable({
  providedIn: 'root'
})
export class TaskServiceService implements OnInit {


  taskArray: ToDoTasks[];
  tasks: ToDoTasks;


  ngOnInit() {
    // this.tasks= new ToDoTasks();
  }
  constructor() {
    this.tasks= new ToDoTasks();
    this.taskArray=[];
  }

  saveTask(tasks){
    tasks.taskStatus = 'incomplete';
     this.taskArray.push(tasks);
    this.tasks= new ToDoTasks();
  }

  getTasks(){
    return this.taskArray;
  }

  updateTask(id: number){
    return this.taskArray[id];
  }

  deleteTask(id: number){
    this.taskArray.splice(id,1);
  }


}

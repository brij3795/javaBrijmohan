export class ToDoTasks{
  public taskName: string;
  public taskStatus: string;
}

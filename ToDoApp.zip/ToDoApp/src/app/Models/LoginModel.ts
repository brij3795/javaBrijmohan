export class LoginModel{
  public userEmail: string;
  public password: string;
}

package com.capgemini.xyz.dao;

//import java.util.ArrayList;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Transaction;

public class ClassDao implements InterfaceDao {

	Map<Long, Customer> customerMap = new HashMap<>();
	ArrayList<Transaction> tranArray = new ArrayList<Transaction>();
	Transaction tran;

	// deposit money in current customer's mobile no account
	@Override
	public String deposit(long mobNo, double amount)
			throws NegativeAmountException {

		if (amount <= 0) {

			throw new NegativeAmountException(
					"Please enter amount greater than 0");

		} else {
			customerMap.get(mobNo).setBalance(
					customerMap.get(mobNo).getBalance() + amount);
			tran = new Transaction("credit", amount, customerMap.get(mobNo)
					.getBalance(), customerMap.get(mobNo).getMobileNo());
			tranArray.add(tran);
		}
		return "Rs " + amount + " deposited successfully at "
				+ LocalDateTime.now() + " for mobile no: " + mobNo
				+ "\n Your updated balance is: " + showBalance(mobNo);
	}

	// withdraw money in current customer's mobile no account
	@Override
	public String withdraw(long mobNo, double amount)
			throws LowBalanceException {

		if (amount > customerMap.get(mobNo).getBalance()) {

			throw new LowBalanceException("Your balance is low");

		} else {
			customerMap.get(mobNo).setBalance(
					customerMap.get(mobNo).getBalance() - amount);
		}
		tran = new Transaction("debit", amount, customerMap.get(mobNo)
				.getBalance(), customerMap.get(mobNo).getMobileNo());
		tranArray.add(tran);
		return "Rs " + amount + " withdrawn successfully at "
				+ LocalDateTime.now() + " for mobile no: " + mobNo
				+ "\n Your updated balance is: " + showBalance(mobNo);
	}

	// checking if the user inputted mobNo and password exists in the map
	@Override
	public boolean login(long mobNo, String password) {

		for (Long key : customerMap.keySet()) {
			if (key == mobNo
					&& customerMap.get(key).getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}

	// inserting the customer obj in the map
	@Override
	public String insertCustomer(Customer customer) {

		customerMap.put(customer.getMobileNo(), customer);
		return "Registration successfull! your username is your mobile number: "
				+ customer.getMobileNo();
	}

	// retrieving balance using current customer's mobile no
	@Override
	public double showBalance(long mobNo) {
		return customerMap.get(mobNo).getBalance();

	}

	// transfer amount from one customer obj to other
	@Override
	public String fundTransfer(long senderMobNo, long receiverMobNo,
			Double amount) throws SenderReceiverSameException,
			LowBalanceException, NegativeAmountException {
		if (senderMobNo == receiverMobNo) {

			throw new SenderReceiverSameException("Cannot send to yourself");

		}
		withdraw(senderMobNo, amount); // withdrawing amount from sender's
										// wallet
		deposit(receiverMobNo, amount); // depositing amount to receiver's
										// wallet
		return amount + " Rs transferred to mobile number: " + receiverMobNo
				+ "\n Your updated balance is: " + showBalance(senderMobNo);
	}

	@Override
	public boolean checkUser(long receiverMobNo) { // finding the user inputted
													// receiverMobNo in the map
		for (Long key : customerMap.keySet()) {
			if (receiverMobNo == customerMap.get(key).getMobileNo()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void printTransaction(long mobNo) {

		for (Transaction t : tranArray) {
			if (t.getMobNo() == mobNo) {
				System.out.println(t.toString());
			}
			// System.out.println(t);
		}
	}
}

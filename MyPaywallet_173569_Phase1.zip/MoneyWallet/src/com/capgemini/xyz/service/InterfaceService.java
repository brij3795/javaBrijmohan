package com.capgemini.xyz.service;

import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;

public interface InterfaceService {

	// declaring Regex for all inputs
	String userNamePattern = "[A-Za-z]{0,20}";
	String emailPattern = "^(.+)@(.+)$";
	String mobNoPattern = "(0/91)?[7-9][0-9]{9}";
	String paswordPattern = "(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$";

	// declaring abstract methods
	boolean validateName(String name);

	boolean validateEmail(String email);

	boolean validateMobNo(String mobNo);

	boolean validatePassword(String password);

	String deposit(long mobNo, double amount) throws NegativeAmountException;

	String withdraw(long mobNo, double amount) throws LowBalanceException;

	boolean login(long mobNo, String password);

	double showBalance(long mobNo);

	String insertCustomer(Customer customer);

	String fundTransfer(long senderMobNo, long receiverMobNo, Double amount)
			throws SenderReceiverSameException, LowBalanceException,
			NegativeAmountException;

	boolean checkUser(long receiverMobNo);

	void printTransaction(long mobNo);
}

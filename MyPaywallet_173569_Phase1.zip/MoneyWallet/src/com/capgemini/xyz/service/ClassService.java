package com.capgemini.xyz.service;

import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.dao.ClassDao;
import com.capgemini.xyz.dao.InterfaceDao;

public class ClassService implements InterfaceService {

	InterfaceDao idao = new ClassDao();

	@Override
	public boolean validateName(String name) {
		if (name.matches(userNamePattern)) { // user name regex validation
			return true;
		} else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(emailPattern)) { // email regex validation
			return true;
		} else
			return false;
	}

	@Override
	public boolean validateMobNo(String mobNo) {
		if (mobNo.matches(mobNoPattern)) { // mobile no regex validation
			return true;
		} else
			return false;
	}

	@Override
	public String deposit(long mobNo, double amount)
			throws NegativeAmountException {
		return (idao.deposit(mobNo, amount)); // calling deposit method of
												// classDao

	}

	@Override
	public String withdraw(long mobNo, double amount)
			throws LowBalanceException {
		return (idao.withdraw(mobNo, amount)); // calling withdraw method of
												// classDao

	}

	@Override
	public boolean login(long mobNo, String password) {
		return (idao.login(mobNo, password)); // calling login method of
												// classDao
	}

	@Override
	public boolean validatePassword(String password) {
		if (password.matches(paswordPattern)) { // password regex validation
			return true;
		} else
			return false;
	}

	@Override
	public String insertCustomer(Customer customer) {
		return (idao.insertCustomer(customer)); // calling insertCustomer method
												// of
		// classDao

	}

	@Override
	public double showBalance(long mobNo) {
		return idao.showBalance(mobNo); // calling showBalance method of
										// classDao
	}

	@Override
	public String fundTransfer(long senderMobNo, long receiverMobNo,
			Double amount) throws SenderReceiverSameException,
			LowBalanceException, NegativeAmountException {
		return (idao.fundTransfer(senderMobNo, receiverMobNo, amount)); // calling
		// fundTransfer
		// method of
		// classDao

	}

	@Override
	public boolean checkUser(long receiverMobNo) {
		return (idao.checkUser(receiverMobNo)); // calling checkUser method of
												// classDao
	}

	@Override
	public void printTransaction(long mobNo) {
		idao.printTransaction(mobNo); // calling printTransaction method of
										// classDao
	}

}

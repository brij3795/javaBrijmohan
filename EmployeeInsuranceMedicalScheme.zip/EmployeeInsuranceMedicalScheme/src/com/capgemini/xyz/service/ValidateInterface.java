package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Employee;

public interface ValidateInterface {
	String USER_NAME_PATTERN = "^[\\p{L} .'-]+$";
	String SALARY = "[0-9]{1,6}";
	String CHOICE = "[1-3]{1}";
	String ID = "[0-9]{5}";

	boolean validateUserName(String userName);

	boolean validateSalary(String salary);

	boolean validateChoice(String ch);

	boolean validateId(String id);

	void storeToList(Employee emp);

	Employee showDetails(int id);
}

package service;

import java.util.ArrayList;

import bean.Customer;
import dao.ClassDao;
import dao.InterfaceDao;

public class ClassService implements InterfaceService {
	
	
	InterfaceDao dao=new ClassDao();

	@Override
	public boolean validateName(String customerName) {
		if(customerName.matches(customerNameRegex))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateEmail(String customerEmail) {
		if(customerEmail.matches(customerEmailRegex))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateAddress(String customerAddress) {
		if(customerAddress.matches(customerAddressRegex))
			return true;
		else
		return false;
	}

	@Override
	public ArrayList<Customer> displayCustomer() {
		
		return dao.displayCustomer();
	}
	
	
	public void storeIntoMap(Customer customer)
	{
		dao.storeIntoMap(customer);
	}
	
	

}

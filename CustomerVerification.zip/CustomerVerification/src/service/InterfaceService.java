package service;

import java.util.ArrayList;

import bean.Customer;

public interface InterfaceService {
	
	String customerNameRegex="[a-zA-Z]{1,10}";
	String customerEmailRegex="[a-zA-Z]{1,10}";
	String customerAddressRegex="[a-zA-Z]{1,10}";
	
	
	public boolean validateName(String customerName);
	
	public boolean validateEmail(String customerEmail);
	
	public boolean validateAddress(String customerAddress);
	
	 ArrayList <Customer> displayCustomer();
	 
	 void storeIntoMap(Customer customer);

}

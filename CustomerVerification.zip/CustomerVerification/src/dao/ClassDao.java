package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import bean.Customer;

public class ClassDao implements InterfaceDao {
	
	Map <Integer, Customer> customerEntry =new HashMap <Integer, Customer>();
	
	private int code;

	@Override
	public void storeIntoMap(Customer customer) {
		code= (int)( Math.random()*10000);
		customer.setCustomerId(code);
		System.out.println(code);
		customerEntry.put(code, customer);
		System.out.println("Your Information is saved succesffly. your customer id"+ code);
		
	}

	@Override
	public ArrayList<Customer> displayCustomer() {
		ArrayList<Customer> lst = new ArrayList<Customer>(
				customerEntry.values());
		return lst;
	}

}

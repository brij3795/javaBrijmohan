package dao;

import java.util.ArrayList;

import bean.Customer;

public interface InterfaceDao {
	
	void storeIntoMap(Customer customer);
	
	
	ArrayList <Customer> displayCustomer();
	
		
	

}

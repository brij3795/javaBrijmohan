package bean;

public class Customer {
	
	private String customerName;
	private String customerEmail;
	private String customerAddress;
	private int customerId;
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerEmail=" + customerEmail + ", customerAddress="
				+ customerAddress + ", customerId=" + customerId + "]";
	}
	
	
	
	
	
}

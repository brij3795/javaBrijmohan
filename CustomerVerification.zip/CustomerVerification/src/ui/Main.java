package ui;

import java.util.Scanner;

import bean.Customer;
import service.ClassService;
import service.InterfaceService;

public class Main {
	
	public static void main(String[] args) {
		
		String customerName=null;
		//String CustomerMobile=null;
		String customerEmail=null;
		String customerAddress=null;
		boolean isValid;
		
		
		InterfaceService input=new ClassService();
		Customer customer=new Customer();
		
		System.out.println("1) Customer Verification");
		System.out.println("2)Login ");
		System.out.println("Exit");
		
		System.out.println("Enter Your Choice");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		
		if(choice==1)
		{
			while(true)
			{
				System.out.println("Enter Your name");
				customerName=sc.next();
				isValid=input.validateName(customerName);
				if(isValid)
					break;
				
				System.out.println("Enter a valid name");
			}
			
			
			while(true)
			{
				System.out.println("Enter Your Mobile");
				customerEmail=sc.next();
				isValid=input.validateEmail(customerEmail);
				if(isValid)
					break;
				
				System.out.println("Enter a valid Email");
			}
			
			while(true)
			{
				System.out.println("Enter Your Address");
				customerAddress=sc.next();
				isValid=input.validateAddress(customerAddress);
				if(isValid)
					break;
				
				System.out.println("Enter a valid Address");
			}
			
			customer.setCustomerAddress(customerAddress);
			customer.setCustomerEmail(customerEmail);
			customer.setCustomerName(customerName);
			
			input.storeIntoMap(customer);
			System.out.println(input.displayCustomer());
			
		}
	}

}

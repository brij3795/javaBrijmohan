package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.customer.Customer;



public class DaoClass implements DaoInterface {
	private Map<Integer, Customer> CustomerEntry = new HashMap<Integer, Customer>();
	
	
	public void storeIntoMap(Customer c)
	{
		CustomerEntry.put(1, c);
		System.out.println("Your Information is Save successfully.");
	}


	@Override
	public ArrayList<Customer> displayCustomer() {
		ArrayList<Customer> lst = new ArrayList<Customer>(
				CustomerEntry.values());
		return lst;
	}

}

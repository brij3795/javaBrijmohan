package com.cg.dao;

import java.util.ArrayList;

import com.cg.customer.Customer;

public interface DaoInterface {
	void storeIntoMap( Customer c);
	
	ArrayList <Customer> displayCustomer();

	

}

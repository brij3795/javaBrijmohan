package com.cg.service;

import java.util.ArrayList;

import com.cg.customer.Customer;

public interface ServiceInterface {
	String userNamePattern = "[a-zA-Z]{1,10}";
	String userMobPattern = "[a-zA-Z]{1,10}";
	String userEmailPattern = "[a-zA-Z]{1,10}";
	String userAddressPattern = "[a-zA-Z]{1,10}";

	boolean validateName(String cName);

	boolean validateMobile(String cMob);

	boolean validateEmail(String cEmail);

	boolean validateAddress(String cAddress);

	void storeIntoMap(Customer c);

	ArrayList<Customer> displayCustomer();

}

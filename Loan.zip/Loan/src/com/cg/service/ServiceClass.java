package com.cg.service;

import java.util.ArrayList;

import com.cg.customer.Customer;
import com.cg.dao.DaoClass;
import com.cg.dao.DaoInterface;

public class ServiceClass implements ServiceInterface {
	
	DaoInterface dao=new DaoClass();

	public boolean validateName(String cName) {
		if (cName.matches(userNamePattern)) {
			return true;
		} else
			return false;
	}

	public boolean  validateMobile (String cMob)

	{
		if (cMob.matches(userMobPattern)) {
			return true;
		} else
			return false;
	}
	public boolean  validateEmail (String cEmail)

	{
		if (cEmail.matches(userEmailPattern)) {
			return true;
		} else
			return false;
	}
	public boolean  validateAddress (String cAddress)

	{
		if (cAddress.matches(userAddressPattern)) {
			return true;
		} else
			return false;
	}
	public void storeIntoMap(Customer c)
	{
		dao.storeIntoMap(c);
	}

	@Override
	public ArrayList<Customer> displayCustomer() {
		return dao.displayCustomer();
	}
	

}

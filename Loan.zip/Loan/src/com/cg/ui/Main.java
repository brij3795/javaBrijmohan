package com.cg.ui;
import java.util.*;

import com.cg.customer.Customer;
import com.cg.service.ServiceClass;
import com.cg.service.ServiceInterface;
public class Main {
	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		boolean isvalid;
		String cName=null;
		String cMob=null;
		String cEmail=null;
		String cAddress=null;
		System.out.println("1. custmer Verification");
		System.out.println("2. Exit");
		System.out.println("please enter your choice.");
		int ch=sc.nextInt();
		
		ServiceClass si=new ServiceClass();
		if(ch==1)
		{
			while (true)
			{
				System.out.println("Enter your name.");
				 cName=sc.next();
				isvalid=si.validateName(cName);
				if(isvalid)
				{
					
					break;
				}
					else 
				
					System.out.println("please Enter a valid name.");
			}
			while(true)
			{
				System.out.println("Enter your Mobile number");
				cMob=sc.next();
				isvalid=si.validateMobile(cMob);
				if(isvalid)
					break;
				else
					System.out.println("please enter a valid mob.");
			}
			while(true)
			{
				System.out.println("Enter your email");
				cEmail=sc.next();
				isvalid=si.validateEmail(cEmail);
				if(isvalid)
					break;
				else
					System.out.println("please enter a valid Email");
			}
			while(true)
			{
				System.out.println("Enter your address");
				cAddress=sc.next();
				isvalid=si.validateAddress(cAddress);
				if(isvalid)
					break;
				else
					System.out.println("please enter a valid address");
			}
			
			Customer c=new Customer();
			c.setcAddress(cAddress);
			c.setcName(cName);
			c.setcEmail(cEmail);
			c.setcMob(cMob);
			si.storeIntoMap(c);
			System.out.println(si.displayCustomer());
			
		}
		
	}

}

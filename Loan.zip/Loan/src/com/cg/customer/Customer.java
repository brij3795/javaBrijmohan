package com.cg.customer;

public class Customer {
	private String cName;
	private String cMob;
	private String cEmail;
	private String cAddress;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcMob() {
		return cMob;
	}
	public void setcMob(String cMob) {
		this.cMob = cMob;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public String getcAddress() {
		return cAddress;
	}
	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}
	@Override
	public String toString() {
		return "customer [cName=" + cName + ", cMob=" + cMob + ", cEmail=" + cEmail + ", cAddress=" + cAddress + "]";
	}
	public Customer(String cName, String cMob, String cEmail, String cAddress) {
		super();
		this.cName = cName;
		this.cMob = cMob;
		this.cEmail = cEmail;
		this.cAddress = cAddress;
	}
	

}

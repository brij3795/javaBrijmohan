package cg.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtil {
	private static Connection connection = null;

	public static Connection getConnection() throws SQLException {


			String url = "jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
			// Class.forName(driver);
			connection = DriverManager.getConnection(url, "Lab1ctrg15", "lab1coracle");
			
		return connection;
	}
}
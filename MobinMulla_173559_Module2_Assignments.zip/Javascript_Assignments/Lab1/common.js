/**
 * 
 */

function addNos(){
	
//	result= headvar + bodyvar;
	return "<h2>The actual script is in external script file called common.js " + ( headvar + bodyvar)+"</h2>";
}

function list(index){
	
	var list2 = document.getElementById("subList");
	
	 switch(index){
	 case "ele":
		list2.options[0] = new Option("Select","");
		list2.options[1] = new Option("Television","20000");
		list2.options[2] = new Option("Laptop","30000");
		list2.options[3] = new Option("Phone","10000");
		break;
	
	 case "gro":
		 list2.options.length = 0;
		list2.options[0] = new Option("Select","");
		list2.options[1] = new Option("Soup","40");
		list2.options[2] = new Option("Powder","90");
		break;
	}
}
	
	function calculate(){
		var price = document.getElementById("subList").value;
		var quantity = document.getElementById("quantity").value;
		result = price*quantity;
		document.getElementById("totalPrice").value = result;
	}

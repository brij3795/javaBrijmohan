package com.capgemini.xyz.ExceptionClass;

public class CustomerExistsException extends Exception {

	public CustomerExistsException() {
		// TODO Auto-generated constructor stub
	}

	public CustomerExistsException(String message) {
		super(message);
	}
}

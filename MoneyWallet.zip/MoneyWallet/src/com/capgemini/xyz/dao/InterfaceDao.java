package com.capgemini.xyz.dao;

import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;

public interface InterfaceDao {

	// declaring abstract methods
	String deposit(long mobNo, double amount) throws NegativeAmountException;

	String withdraw(long mobNo, double amount) throws LowBalanceException;

	boolean login(long mobNo, String password);

	String insertCustomer(Customer customer);

	double showBalance(long mobNo);

	String fundTransfer(long senderMobNo, long receiverMobNo, Double amount)
			throws SenderReceiverSameException, LowBalanceException,
			NegativeAmountException;

	boolean checkUser(long receiverMobNo);

	void printTransaction(long mobNo);
}

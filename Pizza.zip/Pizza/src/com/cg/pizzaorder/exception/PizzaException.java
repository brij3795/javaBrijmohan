package com.cg.pizzaorder.exception;

public class PizzaException extends Exception{

	public PizzaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PizzaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}

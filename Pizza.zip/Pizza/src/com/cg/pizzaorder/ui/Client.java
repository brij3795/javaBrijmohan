package com.cg.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Scanner;

//import com.cg.Exception.PizzaException;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {
	
	public static void main(String[] args) {
		
		
		IPizzaOrderService service=new PizzaOrderService();
		
		Customer customer=new Customer();
		PizzaOrder pizza=new PizzaOrder();
		
		
		 String customerName;
		String address;
		String phone;
		boolean isValid=false;
		int pizzaPrice=0;
		int orderId=0;
		
		
		while(true)
		{
		System.out.println("1) place order");
		System.out.println("2) Display order");
		System.out.println("3)Exit");
		
		System.out.println("Enter Your Choice");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		
		if(choice==1)
		{
			System.out.println("Enter Name");
			customerName=sc.next();
			customer.setCustomerName(customerName);
			
			System.out.println("Enter Address");
			address=sc.next();
			customer.setAddress(address);
			
			while(true)
			{
				System.out.println("Enter customer Mobile");
				phone=sc.next();
				isValid=service.validatePhone(phone);
				if(isValid)
				{
					customer.setPhone(phone);
					break;
				}
				else
					System.out.println("Enter valid phone");
			}
			
			
			System.out.println("Pizza Toppings" +"   "+"price(in Rs");
			System.out.println("Capsicum"+"   "+"30");
			System.out.println("Mushroom"+"   "+"50");
			System.out.println("Jalapeno"+"   "+"70");
			System.out.println("Paneer"+"   "+"90");
			System.out.println("Type of pizza tapping prefered");
			
			String pizzaChoice=sc.next();
			
			try {
				pizzaPrice=service.calculatePizzaPrice(pizzaChoice);
				
				pizza.setTotalPrice(pizzaPrice);
				System.out.println(pizzaPrice);
				
				System.out.println("sytem date"+LocalDate.now());
				
				
				orderId=service.placeOrder(customer,pizza);
				System.out.println("Your Order is Successfully placed orderId "+orderId);
			} catch (PizzaException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		else if(choice==2)
		{
			System.out.println("Enter  OrderId");
		    orderId=sc.nextInt();
		    
		    
		    try {
				pizza=service.getOrderDeatils(orderId);
				System.out.println(pizza);
			} catch (PizzaException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		
		}
		else if(choice==3)
		{
			System.out.println("You are Exited from system");
			System.exit(0);
		}
		
		
		else
			System.out.println("Enter a valid input");
		
		}
	}

}

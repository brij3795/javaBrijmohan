package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO {
	
	int customerId,orderId=0;
	
	Map<Integer, Customer> customerEntry=new HashMap<Integer, Customer>();
	Map<Integer, PizzaOrder> orderEntry= new HashMap<Integer,PizzaOrder>();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) {
		
		customerId=(int)(Math.random()*100);
		pizza.setCustomerId(customerId);
		customerEntry.put(customerId, customer);
		
		
		orderId=(int)(Math.random()*100);
		pizza.setOrderId(orderId);
		orderEntry.put(orderId, pizza);
		
		return orderId;
		
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException{
		// TODO Auto-generated method stub
		
		for(Integer orderIdKey:orderEntry.keySet())
			
			if(orderIdKey==orderId)
				return orderEntry.get(orderIdKey);
			else
				throw new PizzaException("Invalid order Id");
				
				
		return null;
	}

}

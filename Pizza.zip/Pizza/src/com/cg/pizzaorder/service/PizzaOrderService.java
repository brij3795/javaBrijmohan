package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {
	
	IPizzaOrderDAO dao=new PizzaOrderDAO();

	@Override
	public boolean validatePhone(String phone) {
		if (phone.matches(phoneRegex))
			return true;
		else
			return false;
	}
	int pizzaPrice=0;

	@Override
	public int calculatePizzaPrice (String pizzaChoice) throws PizzaException{
		
		pizzaChoice=pizzaChoice.toLowerCase();
		
		switch(pizzaChoice)
		{
		case "capsicum":;
		pizzaPrice=BASE_PRICE+CAPSICUM_PRICE;
		break;
		
		case "mushroom":
			pizzaPrice=BASE_PRICE+MUSHROOM_PRICE;
			break;
			
		case "jalapeno":
			pizzaPrice=BASE_PRICE+JALAPENO_PRICE;
			break;
		case "paneer":
			pizzaPrice=BASE_PRICE+PANEER_PRICE;
			break;
			
			default: throw new PizzaException("Invalid topping selection");
		}
		return pizzaPrice;
		}
		
		
		/* if(pizzaChoice=="capsicum")
			pizzaPrice=BASE_PRICE+CAPSICUM_PRICE;
		
		else if(pizzaChoice=="mushroom")
			pizzaPrice=BASE_PRICE+MUSHROOM_PRICE;
		
		else if(pizzaChoice=="jalapeno")
			pizzaPrice=BASE_PRICE+JALAPENO_PRICE;
		
		else if (pizzaChoice == "paneer")
		{
			pizzaPrice=BASE_PRICE+PANEER_PRICE;
		}
		else
			throw new PizzaException("Invalid topping selection");
		
		return pizzaPrice;*/
		
	

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) {
		return dao.placeOrder(customer,pizza);
	}

	@Override
	public PizzaOrder getOrderDeatils(int orderId) throws PizzaException{
		return dao.getOrderDetails(orderId);
	}

}

package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService {
	
	String phoneRegex="(0/91)?[7-9][0-9]{9}";
	
	
	
	public boolean validatePhone(String phone);



	public int calculatePizzaPrice(String pizzaChoice) throws PizzaException;
	
	
	
	int BASE_PRICE=350;
	int CAPSICUM_PRICE=30;
	int MUSHROOM_PRICE=50;
	int JALAPENO_PRICE=70;
	int PANEER_PRICE=90;



	public int placeOrder(Customer customer, PizzaOrder pizza);



	public PizzaOrder getOrderDeatils(int orderId) throws PizzaException;

}

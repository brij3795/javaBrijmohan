package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {
	@FindBy(id = "next")
	private WebElement next;

	@FindBy(id = "graduation")
	private WebElement graduation;

	@FindBy(id = "percentage")
	private WebElement percentage;

	@FindBy(id = "passingyear")
	private WebElement passingyear;

	@FindBy(id = "project")
	private WebElement project;

	@FindBy(id = "technology")
	private WebElement technology;

	public String getGraduation() {
		return graduation.getAttribute("value");
	}

	public void setGraduation(int i) {
		Select select = new Select(graduation);
		select.selectByIndex(i);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingyear() {
		return passingyear.getAttribute("value");
	}

	public void setPassingyear(String passingyear) {
		this.passingyear.sendKeys(passingyear);
	}

	public String getProject() {
		return project.getAttribute("value");
	}

	public void setProject(String project) {
		this.project.sendKeys(project);
	}

	public String getTechnology() {
		return technology.getAttribute("value");
	}

	public void setTechnology(String technology) {
		this.technology.sendKeys(technology);

	}

	public void clickNext() {
		next.click();

	}
}

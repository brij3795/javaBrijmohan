package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {

	private Education education;
	private WebDriver driver;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver(); // instantiate driver

	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Education page$")
	public void user_is_on_Education_page() throws Throwable {

		String url = "C:\\Users\\msomaiya\\Spring\\BDD-Testing\\html\\EducationalDetails.html";
		driver.get(url);
		education = new Education();
		PageFactory.initElements(driver, education);
	}

	@Then("^Validate Education page$")
	public void validate_Education_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User enters Graduation$")
	public void user_enters_Graduation() throws Throwable {

		education.setGraduation(1);
	}

	@Then("^Validate Graduation$")
	public void validate_Graduation() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Percentage$")
	public void user_enters_Percentage() throws Throwable {
		education.setGraduation(1);
		education.setPercentage("60");
	}

	@Then("^Validate Percentage$")
	public void validate_Percentage() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters PassingYear$")
	public void user_enters_PassingYear() throws Throwable {
		education.setGraduation(1);
		education.setPercentage("60");
		education.setPassingyear("2018");
	}

	@Then("^Validate passingYear$")
	public void validate_passingYear() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Project $")
	public void user_enters_Project_Year() throws Throwable {
		education.setGraduation(1);
		education.setPercentage("60");
		education.setPassingyear("2018");
		education.setProject("Phishing");
	}

	@Then("^Validate Project $")
	public void validate_Project_Year() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Technology$")
	public void user_enters_Technology() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Validate Technology$")
	public void validate_Technology() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

}

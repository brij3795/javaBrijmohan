package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver(); // instantiate driver

	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on personal page$")
	public void user_is_on_personal_page() throws Throwable {
		String url = "C:\\Users\\msomaiya\\Spring\\BDD-Testing\\html\\personalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);

	}

	@Then("^Validate personal page$")
	public void validate_personal_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^User enters first name$")
	public void user_enters_first_name() throws Throwable {
		personal.setFirstname("mohit");
	}

	@Then("^Validate First Name$")
	public void validate_First_Name() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters last name$")
	public void user_enters_last_name() throws Throwable {
		personal.setFirstname("mohit");
		personal.setLastname("");
	}

	@Then("^Validate last Name$")
	public void validate_last_Name() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters email$")
	public void user_enters_email() throws Throwable {
		personal.setFirstname("mohit");
		personal.setLastname("somaiya");
		personal.setEmail("m@b.com");

	}

	@Then("^Validate email$")
	public void validate_email() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters contact$")
	public void user_enters_contact() throws Throwable {
		personal.setFirstname("mohit");
		personal.setLastname("somaiya");
		personal.setEmail("m@b.com");
		personal.setContact("9769476850");
	}

	@Then("^Validate contact$")
	public void validate_contact() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Address(\\d+)$")
	public void user_enters_Address(int arg1) throws Throwable {
		personal.setFirstname("mohit");
		personal.setLastname("somaiya");
		personal.setEmail("m@b.com");
		personal.setContact("9769476850");
		personal.setAddress1("5, Satyam");

	}

	@Then("^Validate Address(\\d+)$")
	public void validate_Address(int arg1) throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^User enters address(\\d+) name$")
	public void user_enters_address_name(int arg1) throws Throwable {

		personal.setFirstname("mohit");
		personal.setLastname("somaiya");
		personal.setEmail("m@b.com");
		personal.setContact("9769476850");
		personal.setAddress1("5, Satyam");
		personal.setAddress2("garodia nagar");
	}

	@Then("^Validate address(\\d+)$")
	public void validate_address(int arg1) throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters city$")
	public void user_enters_city() throws Throwable {
		personal.setFirstname("mohit");
		personal.setLastname("somaiya");
		personal.setEmail("m@b.com");
		personal.setContact("9769476850");
		personal.setAddress1("5, Satyam");
		personal.setAddress2("garodia nagar");
		personal.setCity(1);
	}

	@Then("^Validate city$")
	public void validate_city() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters state$")
	public void user_enters_state() throws Throwable {
		personal.setFirstname("mohit");
		personal.setLastname("somaiya");
		personal.setEmail("m@b.com");
		personal.setContact("9769476850");
		personal.setAddress1("5, Satyam");
		personal.setAddress2("garodia nagar");
		personal.setCity(1);
		personal.setState(2);
	}

	@Then("^Validate state$")
	public void validate_state() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^when submit details$")
	public void when_submit_details() throws Throwable {
		personal.setFirstname("mohit");
		personal.setLastname("somaiya");
		personal.setEmail("m@b.com");
		personal.setContact("9769476850");
		personal.setAddress1("5, Satyam");
		personal.setAddress2("garodia nagar");
		personal.setCity(1);
		personal.setState(2);
	}

	@Then("^Show successful alert$")
	public void show_successful_alert() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	//	driver.navigate().to("C:\\Users\\msomaiya\\Spring\\BDD-Testing\\html\\EducationalDetails.html");
	}

}
